<?php
namespace Aws\CloudHsm\Exception;

use Aws\Exception\AwsException;

/**
 * AWS CloudHSM exception.
 */
class CloudHsmException extends AwsException {}
